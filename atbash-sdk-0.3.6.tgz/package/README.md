# @atbash/sdk

TypeScript SDK for Atbash — the safety layer that evaluates AI agent actions against operator-defined policies before execution.

## Installation

```bash
npm install @atbash/sdk
```

Requires Node.js 18+. Server-side only — private keys are used for local signing and must never be exposed to browsers.

## Quickstart

```ts
import { loadAgent, judgeAction } from "@atbash/sdk";

// 1. Load your agent identity using the private key you saved during
//    agent creation. loadAgent() validates the key and derives the
//    matching public key for you.
const agent = loadAgent(process.env.ATBASH_AGENT_PRIVKEY!);

// 2. Submit an action for judgment, before executing it.
//    The SDK signs and broadcasts log_tool_call to the Chromia chain
//    (private key stays local), then requests a verdict from the judge API.
const result = await judgeAction(
  "Transfer $50,000 to external wallet 0xabc",
  "Outbound AML check — new recipient, over threshold",
  agent,
);

// 3. Enforce the verdict
switch (result.verdict) {
  case "ALLOW":
    // Proceed with the action
    break;
  case "HOLD":
    // Held — operator must approve in the dashboard
    console.log("Held for review:", result.tool_call_id);
    break;
  case "BLOCK":
    // Refused — agent is jailed in Enforcement tier
    throw new Error(`Blocked: ${result.reason}`);
}
```

Before this works, the agent must be onboarded at [atbash.ai](https://atbash.ai/) — assigned to an org, with a policy pack attached, and the org tier set to Audit+ or Enforcement.

### How it works

`judgeAction()` performs a two-step flow:

1. **Sign on-chain** — signs and broadcasts a `log_tool_call` transaction to the Chromia blockchain using the agent's private key. The key never leaves your machine.
2. **Request verdict** — sends the resulting `tool_call_id` and `agent_pubkey` to the Atbash judge API. No private key is transmitted over HTTP.

If you need finer control, you can call `logToolCall()` and the judge API separately.

### Don't have an agent yet?

There are two ways to create an agent:

1. **Dashboard (recommended)** — create an agent at [atbash.ai/risk-engine/agents](https://atbash.ai/risk-engine/agents). The dashboard generates the keypair, assigns the agent to your org, and lets you attach a policy pack — all in one step.

2. **Programmatic** — generate a new keypair locally or bring an existing secp256k1 private key from another platform, then onboard it via the dashboard:

```ts
import { generateKeyPair, loadAgent } from "@atbash/sdk";

const { privKey } = generateKeyPair();
console.log("Save this private key somewhere safe:", privKey);
const agent = loadAgent(privKey);
```

> **Note:** After generating a key programmatically, you must still onboard the agent at [atbash.ai/risk-engine/agents](https://atbash.ai/risk-engine/agents) — assign it to an org and attach a policy pack before `judgeAction` will work.

### Secret storage

The private key is used to sign on-chain transactions locally. Treat it like any other long-lived credential:

- Load it from an environment variable (`ATBASH_AGENT_PRIVKEY`) or a secret manager (AWS Secrets Manager, HashiCorp Vault, 1Password, etc.) — never hardcode it.
- Never commit `.env` files containing the key. Add them to `.gitignore`.
- If a key leaks, revoke the agent and create a new one in the [Atbash dashboard](https://atbash.ai/risk-engine/agents).
- The SDK is **server-side only** — the key must never ship to a browser bundle.

## Verdicts

Every `judgeAction` call returns one of three verdicts:

| Verdict | Meaning | What your code should do |
|---------|---------|-------------------------|
| `ALLOW` | Action is within policy | Proceed with execution |
| `HOLD` | Requires operator review | Pause — poll `getJudgmentStatus` until resolved |
| `BLOCK` | Violates a red line | Abort — agent is jailed in Enforcement tier |

> **NB:** If your org is on the **Audit** tier, the judge returns `"No verdict"` — actions are logged on-chain for the audit trail but not evaluated by an AI provider. Upgrade to **Audit+** or **Enforcement** at [atbash.ai/risk-engine/settings](https://atbash.ai/risk-engine/settings) for active verdicts.

## API

### Judge

```ts
judgeAction(
  action: string,
  context: string,
  auth: AgentAuth,
  opts?: JudgeOptions,
): Promise<JudgeResult>
```

Submit an action for judgment before execution. Signs `log_tool_call` on-chain, then requests a verdict. Returns the verdict, reason, confidence, provider, latency, and tool call ID.

```ts
interface AgentAuth {
  pubkey: string;   // 66-char hex, secp256k1 compressed public key
  privkey: string;  // 64-char hex private key (used for local signing only)
}

interface JudgeOptions {
  endpoint?: string;          // API base URL (default: https://atbash.ai)
  timeout?: number;           // Request timeout in ms
  provider?: string;          // "openai" | "google" | "microsoft" | "custom"
  model?: string;             // Model override (e.g. "gpt-4o-mini")
  toolName?: string;          // Tool name for audit trail
  toolArgsJson?: string;      // Tool arguments JSON for audit trail
  chainOpts?: ChainOpts;      // Override Chromia chain connection
}

interface ChainOpts {
  nodeUrls?: string[];        // Chromia node URLs (uses the default  nodeurls)
  blockchainRid?: string;     // Blockchain RID (uses the default chromia rid)
}

interface JudgeResult {
  verdict: string;       // "ALLOW", "HOLD", or "BLOCK"
  action_type: string;   // "allow", "hold_for_user_confirm", or "block"
  reason: string;        // Human-readable explanation
  confidence: number;    // 0–1
  provider: string;      // Which provider evaluated the action
  latency_ms: number;    // Inference time
  tool_call_id: string;  // Unique ID for this judgment
  on_chain: boolean;     // Whether the record was written on-chain
}
```

### Log tool call (low-level)

```ts
logToolCall(
  action: string,
  context: string,
  auth: AgentAuth,
  chainOpts?: ChainOpts,
  extra?: { toolName?: string; toolArgsJson?: string },
): Promise<LogToolCallResult>
```

Sign `log_tool_call` on the Chromia chain. Returns `{ success, toolCallId, error? }`. Use this if you need to separate the on-chain logging step from the verdict request.

### Poll judgment status

```ts
getJudgmentStatus(judgmentId: string, opts?: ClientOpts): Promise<JudgmentStatus>
```

Check whether a held action has been approved or rejected by an operator.

```ts
interface JudgmentStatus {
  status: "pending" | "answered" | "error";
  verdict: string;
  reason: string;
  judgmentId: string;
  onChain?: boolean;
  cached?: boolean;
  responseTimeMs?: number;
}
```

### Agent identity

```ts
loadAgent(privkey: string): AgentAuth
generateKeyPair(): { privKey: string; pubKey: string }
derivePublicKey(privKeyHex: string): string
isValidPrivateKey(hex: string): boolean
toPubkeyHex(val: unknown): string
```

`loadAgent(privkey)` is the canonical loader — pass in the private key from the dashboard, get back `{ pubkey, privkey }` ready for `judgeAction`. It accepts `0x`-prefixed, padded, or mixed-case input and throws on malformed keys. Use `generateKeyPair()` only for local development; for production, create agents in the dashboard so operators can attach policies.

### Operations

Functions that sign transactions and write to the Chromia blockchain.

| Function | Use case |
|----------|----------|
| `judgeAction(action, context, auth, opts?)` | Sign `log_tool_call` on-chain + request a verdict from the judge API |
| `logToolCall(action, context, auth, ...)` | Sign and broadcast `log_tool_call` to chain without requesting a verdict |

### Queries

| Function | Use case |
|----------|----------|
| `checkAgentExists(pubkey, opts?)` | Check if an agent is onboarded before signing |
| `getJudgmentStatus(judgmentId, opts?)` | Poll whether a held action has been approved or rejected |
| `getToolCalls(maxCount)` | List recent tool calls across all agents |
| `getOrgToolCalls(orgName, maxCount)` | List tool calls for a specific org |
| `getAgentToolCalls(pubkey, maxCount)` | List tool calls for a specific agent |
| `getToolCallCount()` | Get total number of tool calls on-chain |
| `getToolCallFull(toolCallId)` | Get full details of a single tool call (verdict, context, timing) |
| `getOrgTierInfo(orgName)` | Check an org's tier and whether verdicts are enabled |
| `getAgentDetail(pubkey)` | Get agent metadata (org, status, creation date) |
| `getAgentPolicy(pubkey)` | Check agent's policy pack and jail status |
| `getPendingHeldActions(orgName, maxCount)` | List actions waiting for operator approval |
| `getHeldActionReviews(orgName, maxCount)` | List completed operator reviews |
| `getSafetyStats()` | Get chain-wide safety statistics (total judgments, verdicts, etc.) |

## Configuration

The SDK reads no environment variables and has no global state. Pass configuration explicitly:

```ts
// Custom endpoint
const result = await judgeAction(action, context, auth, {
  endpoint: "https://your-instance.example.com",
});

// Custom provider (API keys are saved in the dashboard, not passed here)
const result = await judgeAction(action, context, auth, {
  provider: "openai",
  model: "gpt-4o",
});

```

> **Advanced:** The SDK connects to the default Atbash Chromia chain. To use a different chain, pass `chainOpts` with custom `nodeUrls` and `blockchainRid` in `JudgeOptions`.

## Integration patterns

### Pre-execution gate

```ts
async function safeExecute(action: string, context: string, execute: () => Promise<void>) {
  const result = await judgeAction(action, context, auth);
  if (result.verdict === "BLOCK") throw new Error(`Blocked: ${result.reason}`);
  if (result.verdict === "HOLD") throw new Error(`Held for review: ${result.tool_call_id}`);
  await execute();
}
```

### Polling a held action

```ts
async function waitForApproval(toolCallId: string): Promise<string> {
  while (true) {
    const status = await getJudgmentStatus(toolCallId);
    if (status.status === "answered") return status.verdict;
    if (status.status === "error") throw new Error(status.reason);
    await new Promise((r) => setTimeout(r, 5000));
  }
}
```

### Checking agent jail status

```ts
const policy = await getAgentPolicy(pubKey);
if (policy.is_jailed) {
  console.error("Agent is jailed — unjail via dashboard before retrying.");
  process.exit(1);
}
```

## Error handling

The SDK throws standard `Error` objects. Known failure modes are enriched with a pointer to the relevant dashboard page, so the error message tells you where to fix the problem:

```
API error 404: {"error":"Agent not registered..."}
  → Onboard the agent at https://atbash.ai/risk-engine/agents
```

| Error | Cause | Where to fix |
|---|---|---|
| `API error 404: Agent not registered` | Agent not onboarded | [atbash.ai/risk-engine/agents](https://atbash.ai/risk-engine/agents) |
| `API error 400: Agent has no policy` | No policy attached to agent | [atbash.ai/risk-engine/agents](https://atbash.ai/risk-engine/agents) |
| `Agent is jailed` | BLOCK verdict triggered auto-jail (Enforcement tier) | [atbash.ai/risk-engine/agents](https://atbash.ai/risk-engine/agents) |
| `Org tier does not support verdicts` | Org is on Audit tier | [atbash.ai/risk-engine/settings](https://atbash.ai/risk-engine/settings) |
| `API error 400: action is required` | Empty action string | Fix caller |
| `API error 502: Incorrect API key` | Invalid provider API key | Check saved key at [atbash.ai/risk-engine/settings](https://atbash.ai/risk-engine/settings) |

```ts
try {
  const result = await judgeAction(action, context, auth);
} catch (err) {
  if (err.message.includes("Agent not registered")) {
    // Point the user at https://atbash.ai/risk-engine/agents to onboard.
  }
}
```

## Dashboard

Policy authoring, operator reviews, and agent management happen at [atbash.ai](https://atbash.ai/). The SDK is the programmatic interface; the dashboard is the operator interface.

## License

Proprietary — all rights reserved. See [LICENSE](https://atbash.ai/license).
